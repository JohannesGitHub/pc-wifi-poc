<?php
  $WLANGUEST_DIR="/var/www/wlanguests/";
  $WLAN_PIN_FILE=$WLANGUEST_DIR."wlanpin";

  if($_SERVER["SERVER_NAME"] != $_SERVER["SERVER_ADDR"]):
    header("Location: http://".$_SERVER["SERVER_ADDR"]."/");
  else:
    session_start();
    $WLAN_PIN = file_get_contents($WLAN_PIN_FILE);
    if($WLAN_PIN === false)
      $WLAN_PIN = "";
    else
      $WLAN_PIN = trim($WLAN_PIN);
    $ARP_TB = file("/proc/net/arp");
    $MAC_ADDR = "";
    if($ARP_TB !== false) {
      foreach ($ARP_TB as $ARP_E) {
        if(0 === strpos($ARP_E, $_SERVER["REMOTE_ADDR"]." ")) {
          $MAC_ADDR=str_replace(':','',substr($ARP_E,41,17));
          break;
        }
      }
    }
?>
<html>
<head>
  <title>c&apos;t G&auml;ste-WLAN</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="portal">
    <h1>c&apos;t G&auml;ste-WLAN</h1>
    <h3>Internetzugang f&uuml;r Besucher</h3>
    <h4>c&apos;t 26/2017, S. 154</h4>
  </div>

<?php if(!empty($MAC_ADDR)
          && file_exists($WLANGUEST_DIR.$MAC_ADDR)):
        if(!empty($_POST['logout'])
            && $_POST['logout']=="yes"
            && unlink($WLANGUEST_DIR.$MAC_ADDR)):
?>
  <div class="buttonbox" align="center">
    <h3>Sie haben sich abgemeldet</h3>
    <h4><a href="/">Wieder anmelden</a></h4>
  </div>
<?php   else: ?>
  <div class="buttonbox" align="center">
    <form method="POST">
      <h3>Sie sind angemeldet</h3>
      <button name="logout" value="yes">Abmelden</button>
    </form>
  </div>
<?php   endif;
      elseif(!empty($_POST['acceptagb'])
          && $_POST['acceptagb']=="yes"
          && !empty($_POST['wlanpin'])
          && $_POST['wlanpin']==$WLAN_PIN
          && !empty($MAC_ADDR)):
        sleep(2);
        file_put_contents($WLANGUEST_DIR.$MAC_ADDR,$_SERVER["REMOTE_ADDR"]."\n");
        unlink($WLAN_PIN_FILE);
        sleep(2);
?>
  <div class="buttonbox" align="center">
    <h3>Willkommen</h3>
    <h4><a href="/" target="_new">Zum Portal</a></h4>
  </div>
<?php else:
        if(!file_exists($WLAN_PIN_FILE))
          file_put_contents($WLAN_PIN_FILE,random_int(100000,999999)."\n");
?>
  <div class="hidebox">
    <input id="nutzungsbedingungen" class="toggle" type="checkbox">
    <label for="nutzungsbedingungen"></label>
    <cite>Nutzungsbedingungen</cite>
    <div>
      <p>Platz f&uuml;r Ihre Nutzungsbedingungen</p>
    </div>
  </div>
  <div class="buttonbox" align="center">
    <form method="POST">
      <p align="center">
        PIN: <input type="password" name="wlanpin" value=""><br>
        <small>Ihre PIN wird auf dem Display des Raspberry Pi angezeigt.</small>
      </p>
      <button name="acceptagb" value="yes">Nutzungsbedingungen akzeptieren &amp; anmelden</button>
    </form>
  </div>
<?php endif; ?>
  </div>
</body>
</html>
<?php
  endif;
?>
